import React from 'react';
const PlaceOrderTable=()=>{
    return(
        <>
            <h1>Im place order Table</h1>
        </>
    )
}

export default  PlaceOrderTable;