// ["Shirt", "Saree", "Jeans", "Trousers", "Joggers", "Suits", "Gowns"];
const orderDetails={
    "Shirt":{
        "Quantity":0,
        "Service":[]
    },
    "Saree": {
        "Quantity": 0,
        "Service": []
    },
    "Jeans": {
        "Quantity": 0,
        "Service": []
    },
    "Trousers": {
        "Quantity": 0,
        "Service": []
    },
    "Suits": {
        "Quantity": 0,
        "Service": []
    },
    
    "Gowns": {
        "Quantity": 0,
        "Service": []
    }
}
export default orderDetails;