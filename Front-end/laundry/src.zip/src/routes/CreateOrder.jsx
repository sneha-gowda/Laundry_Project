import React from 'react';
import Washing from "./img/washing-machine.jpg"
import Ironing from "./img/ironing.svg"
import Fold from "./img/towel.svg"
import Bleach from "./img/bleach.svg"

import "./createOrder.css"

const product = [
    {
        "_id": "61ed33b32fa5e9f0a5bb771e",
        "Price": 10,
        "ImageURL": "https://5.imimg.com/data5/WI/EB/MY-45054986/boys-designer-shirts-500x500.jpg",
        "ProductName": "Shirt"
    },
    {
        "_id": "61ed342e2fa5e9f0a5bb771f",
        "ProductName": "Saree",
        "Price": 50,
        "ImageURL": "https://media.glamour.com/photos/5fda4db65bafc7ef56c335eb/1:1/w_1800,h_1800,c_limit/jeans.jpeg"
    },
    {
        "_id": "61ed34f22fa5e9f0a5bb7721",
        "ProductName": "Jeans",
        "Price": 20,
        "ImageURL": "https://media.glamour.com/photos/5fda4db65bafc7ef56c335eb/1:1/w_1800,h_1800,c_limit/jeans.jpeg"
    },
    {
        "_id": "61ed35162fa5e9f0a5bb7722",
        "ProductName": "Trousers",
        "Price": 30,
        "ImageURL": "https://media.glamour.com/photos/5fda4db65bafc7ef56c335eb/1:1/w_1800,h_1800,c_limit/jeans.jpeg"
    },
    {
        "_id": "61ed353b2fa5e9f0a5bb7723",
        "Price": 20,
        "ImageURL": "https://5.imimg.com/data5/WI/EB/MY-45054986/boys-designer-shirts-500x500.jpg",
        "ProductName": "Joggers"
    },
    {
        "_id": "61ed355a2fa5e9f0a5bb7724",
        "ProductName": "Suits",
        "Price": 50,
        "ImageURL": "https://media.glamour.com/photos/5fda4db65bafc7ef56c335eb/1:1/w_1800,h_1800,c_limit/jeans.jpeg"
    },
    {
        "_id": "61ed356d2fa5e9f0a5bb7725",
        "ProductName": "Gowns",
        "Price": 50,
        "ImageURL": "https://media.glamour.com/photos/5fda4db65bafc7ef56c335eb/1:1/w_1800,h_1800,c_limit/jeans.jpeg"
    }
]


const CreateOrder = () => {
  return <div>
 <table className='prod-table'>
     <thead>
     <tr>
         <th  >Product Name</th>
         <th >Quantity</th>
         <th >Wash Type</th>
         <th >Price</th>
         
     </tr>
     </thead>
     <tbody>
         {product.map((row) => {
             return(
        <tr>
            <td className='col-1 col'>
                <img src={row.ImageURL} alt="" height={50} width={50} />&nbsp;&nbsp;&nbsp;
                {row.ProductName}
                </td>
            <td className='col-2 col'><input type="Number" /></td>
            <td className='col-3 col'> 
            <img src={Washing} alt="Washing" />&nbsp;&nbsp;&nbsp;&nbsp;
            <img src={Ironing} alt="Ironing" />&nbsp;&nbsp;&nbsp;&nbsp;
            <img src={Fold} alt="Fold" />&nbsp;&nbsp;&nbsp;&nbsp;
            <img src={Bleach} alt="Bleach" />
            
            </td>
            <td className='col-4 col'>{row.Price}</td>
        </tr>
        

         )})}
     </tbody>
 </table>

  </div>;
};

export default CreateOrder;
