import React from "react";
import "./refer.css"
const Refer=()=>{
    return(
        <>
            <section className="Refer">
                <h1>Now Refer & Earn ₹500 for every referral*</h1>
                <h6>* Terms and conditions will be applied</h6>
            </section>
        </>
    )
}
export default Refer;