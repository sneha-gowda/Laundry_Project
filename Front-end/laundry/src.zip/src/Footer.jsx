import React from "react";
import "./footer.css"
const Footer=()=>{
    return (
        <>
            <footer className="Footer">
                <p>2021 <span>&#169;</span> Laundry</p>
            </footer>
        </>
    )
}
export default Footer;